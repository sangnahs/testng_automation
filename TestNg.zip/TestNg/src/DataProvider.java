import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;




public class DataProvider {

	WebDriver driver;
	@org.testng.annotations.DataProvider(name = "Authentication")
	public static Object[][] credentials(){
		return new Object[][] { { "testuser_1", "Test@123" }, { "testuser_1", "Test@123" }};
	}
	
	@Test(dataProvider="Authentication")
	public void test(String Username, String Password) throws InterruptedException{
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("https://www.gmail.com/");
		 
		 String parentWindow= driver.getWindowHandle();
		 System.out.println("parentwindow" +parentWindow);
		 driver.findElement(By.id("identifierId")).sendKeys(Username);
		 driver.findElement(By.xpath("//span[contains(text(),'Next')]")).click();
		 
		 
		 for(String childWindow: driver.getWindowHandles())
		 {
			 System.out.println("childwindow" +childWindow);
			 driver.switchTo().window(childWindow);
			 Thread.sleep(5000);
			 driver.findElement(By.xpath("//input[@name='password']")).sendKeys(Password);
			 driver.findElement(By.xpath("//span[contains(text(),'Next')]")).click();
		 }

	}
}
