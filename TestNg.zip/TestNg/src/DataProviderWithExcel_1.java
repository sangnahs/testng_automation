import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class DataProviderWithExcel_1 {

	WebDriver driver;
	@BeforeMethod
	 
    public void beforeMethod() throws Exception {

	    driver = new ChromeDriver();

        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.get("https://www.gmail.com/");
	}
        
        @Test(dataProvider="Authentication")
        
public void RegisterData(String Username,  String Password) throws Exception
        {
     
        	 String parentWindow= driver.getWindowHandle();
    		 System.out.println("parentwindow" +parentWindow);
    		 driver.findElement(By.id("identifierId")).sendKeys(Username);
    		 driver.findElement(By.xpath("//span[contains(text(),'Next')]")).click();
    		 
    		 
    		 for(String childWindow: driver.getWindowHandles())
    		 {
    			 System.out.println("childwindow" +childWindow);
    			 driver.switchTo().window(childWindow);
    			 Thread.sleep(5000);
    			 driver.findElement(By.xpath("//input[@name='password']")).sendKeys(Password);
    			 driver.findElement(By.xpath("//span[contains(text(),'Next')]")).click();
    		 }
     
        }
	
        @DataProvider
     
        public Object[][] Authentication() throws Exception{
     
             Object[][] testObjArray = ExcelUtils.getTableArray("C://Users//c5253597//Documents//TestNg//testData.xlsx","Sheet1");
     
             return (testObjArray);
     
    		}
     
           
    
	}

