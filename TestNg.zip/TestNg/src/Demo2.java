import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Demo2 {

	public WebDriver driver;
	  @Test
	  public void f() throws InterruptedException {
		  //System. setProperty("webdriver.chrome.driver", "C:\\Users\\C5239340\\eclipse-workspace\\test\\chromedriver.exe");
			 driver=new ChromeDriver();
			 
			 driver.get("https://www.gmail.com/");
			 
			 String parentWindow= driver.getWindowHandle();
			 System.out.println("parentwindow" +parentWindow);
			 driver.findElement(By.id("identifierId")).sendKeys("sangnaharapanahalli");
			 driver.findElement(By.xpath("//span[contains(text(),'Next')]")).click();
			 
			 
			 for(String childWindow: driver.getWindowHandles())
			 {
				 System.out.println("childwindow" +childWindow);
				 driver.switchTo().window(childWindow);
				 Thread.sleep(5000);
				 driver.findElement(By.xpath("//input[@name='password']")).sendKeys("666kempi");
				 driver.findElement(By.xpath("//span[contains(text(),'Next')]")).click();
				 
			 }
			 //driver.findElement(By.xpath(xpathExpression))
			 //driver.findElement(By.id("identifierId")).sendKeys("sangnaharapanahalli");
			//driver.findElement(By.xpath("//span[contains(text(),'Next')]")).click();
			//driver.findElement(By.xpath("//div[@id='password']")).sendKeys("666kempi");
			//driver.findElement(By.xpath("//span[contains(text(),'Next')]")).click();
	  }
}
