import org.testng.Assert;
import org.testng.annotations.Test;

public class Demo3 {

	@Test
	
	public void testOne(){
		System.out.println(Thread.currentThread().getId());
	}
	
	@Test
	
	public void testTwo(){
		System.out.println( Thread.currentThread().getId());
	}
	
	@Test
	public void testThree(){
		System.out.println(Thread.currentThread().getId());
	}
	
}
