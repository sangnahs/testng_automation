import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Demo4 {
	WebDriver driver;
	@BeforeMethod
	public void webDriver(){
		 driver = new ChromeDriver();
		}
	
	@Test
	public void launchYoutube(){
		driver.get("https://www.youtube.com/");
		System.out.println(Thread.currentThread().getId());
	}
	
	@Test
	public void launchFaceBook(){
		driver.get("https://www.facebook.com/");
		System.out.println(Thread.currentThread().getId());
	}
	@Test
	public void launchFlipkart(){
		driver.get("https://www.flipkart.com/");
		System.out.println(Thread.currentThread().getId());
	}
	
}
