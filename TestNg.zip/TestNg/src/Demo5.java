import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Demo5 {

WebDriver driver;


	

@Test
public void launchYoutube(){
	 driver = new ChromeDriver();

	driver.get("https://www.youtube.com/");
	System.out.println(Thread.currentThread().getId());
}

@Test
public void launchFaceBook(){
	  //System. setProperty("webdriver.chrome.driver", "C:\\Users\\C5239340\\eclipse-workspace\\test\\chromedriver.exe");

	driver.get("https://www.facebook.com/");
	System.out.println(Thread.currentThread().getId());
}
@Test
public void launchFlipkart(){
	driver.get("https://www.flipkart.com/");
	System.out.println(Thread.currentThread().getId());
}

}