import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class Demo6 {

	public WebDriver driver;
	@Parameters("myBrowser")
	@BeforeClass
	public void launchBrowser(String myBrowser){
		if(myBrowser.equalsIgnoreCase("firefox")){
			  System. setProperty("webdriver.gecko.driver", "C:\\Users\\c5253597\\Downloads\\geckodriver-v0.12.0-win64");
			driver = new FirefoxDriver();
		}
		else if(myBrowser.equalsIgnoreCase("chrome")){
			driver = new ChromeDriver();
		}
	}
	
	@Test
	public void tc_1(){
		driver.get("https://www.facebook.com/");
	}

}
