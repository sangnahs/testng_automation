import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class ReadDataProvider {
@Test(dataProvider="data")
public void test1(String Col2,String Col3,String Col4){
	
	System.out.println(Col2+","+Col3+","+Col4);
	
}

@DataProvider
public Object[][] data() throws Exception{
    
    Object[][] testObjArray = ExcelUtils.getTableArray("C://Users//c5253597//Documents//TestNg//readData.xlsx","Sheet1");

    return (testObjArray);

	}
}
