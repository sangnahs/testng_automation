import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

public class loginApp {

	WebDriver driver;
	@Test(priority=1,description="application start")
	
	public void gmailApp(){
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.myntra.com/");
		String url = driver.getCurrentUrl();
		Assert.assertTrue(url.contains("accounts.google.com/signin/"));
		
	}
	
	@Test(priority=2,description="login",dependsOnMethods="gmailApp")
	
	public void login(){
		driver.findElement(By.id("identifierId")).sendKeys("sangnaharapanahalli");
		driver.findElement(By.xpath("//span[contains(text(),'Next')]")).click();
		
		
	}
	@Test(priority=3,dependsOnMethods="login")
	public void enterPassword() throws InterruptedException {
		//driver.findElement(By.xpath("//div[@id='password']")).click();
		//driver.findElement(By.xpath("//span[contains(text(),'Next')]")).click();
       // WebDriverWait wait = new WebDriverWait(driver, 10);
		
		
        //driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
       WebElement pass = driver.findElement(By.xpath("//input[@name='password']"));
       WebDriverWait wait = new WebDriverWait(driver, 20);
       wait.until(ExpectedConditions.elementToBeClickable(pass));
       pass.sendKeys("666kempi");
		driver.findElement(By.xpath("//span[contains(text(),'Next')]")).click();
		//driver.findElement(By.xpath("//div[@id='forgotPassword']")).click();
	}

}
