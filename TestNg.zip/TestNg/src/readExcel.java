import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.sl.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class readExcel {

	
public void readExcelFile(String FilePath,String fileName, String sheetName) throws IOException{
	File f = new File(FilePath+"//"+fileName);
	FileInputStream inputStream = new FileInputStream(f);
	Workbook wb = null;
	String fileExtension = fileName.substring(fileName.indexOf("."));
	if(fileExtension.equals(".xlsx")){
		wb = new XSSFWorkbook(inputStream);
		
	}
	else if(fileExtension.equals(".xls")){

        //If it is xls file then create object of XSSFWorkbook class

        wb = new HSSFWorkbook(inputStream);

    }

	Sheet sn = (Sheet) wb.getSheet(sheetName);
	int rowCount = ((org.apache.poi.ss.usermodel.Sheet) sn).getLastRowNum()-((org.apache.poi.ss.usermodel.Sheet) sn).getFirstRowNum();
    for (int i = 0; i < rowCount+1; i++) {

        Row row = ((org.apache.poi.ss.usermodel.Sheet) sn).getRow(i);

        //Create a loop to print cell values in a row

        for (int j = 0; j < row.getLastCellNum(); j++) {

            //Print Excel data in console

            System.out.print(row.getCell(j).getStringCellValue()+"|| ");

        }

        System.out.println();

    }
}
public static void main(String...strings) throws IOException{
	readExcel objFile = new readExcel();
	String FilePath = "C://Users//c5253597//Documents//TestNg";
	objFile.readExcelFile(FilePath, "readData.xlsx", "Sheet1");
}
}
