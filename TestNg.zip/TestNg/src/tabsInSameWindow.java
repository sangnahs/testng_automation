import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class tabsInSameWindow {
	WebDriver driver;
	
	@Test
	public void newTab(){
		driver = new ChromeDriver();
		driver.get("https://www.google.co.in/?gfe_rd=cr&dcr=0&ei=SiV0WoWZNIyjX8T-vsAG");
		String selectLinkOpeninNewTab = Keys.chord(Keys.CONTROL,"t"); 

		driver.findElement(By.cssSelector("body")).sendKeys(selectLinkOpeninNewTab);  
}
}
