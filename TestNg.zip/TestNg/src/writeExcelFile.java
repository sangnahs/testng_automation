import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Test;

public class writeExcelFile {
	@Test(priority=1)
	public void writeData() throws IOException{
		
	FileInputStream fis = new FileInputStream("C://Users//c5253597//Documents//TestNg//writeData.xlsx");
	XSSFWorkbook wb = new XSSFWorkbook(fis);
	XSSFSheet sheet = wb.getSheet("Sheet1");
	int rowCount = sheet.getLastRowNum()-sheet.getFirstRowNum();
	System.out.println(rowCount);
	Row row = sheet.getRow(0);
	Row newrow = sheet.createRow(rowCount+2);
	Cell cell = newrow.createCell(1);
	//cell.setCellType(Cell.CELL_TYPE_STRING);
	cell.setCellValue("instered data");
	FileOutputStream fos = new FileOutputStream("C://Users//c5253597//Documents//TestNg//writeData.xlsx");
	wb.write(fos);
	fos.close();
	
	System.out.println("inserted");
		}
	@Test(priority=2)
	public void readData() throws IOException{
		FileInputStream fis = new FileInputStream("C://Users//c5253597//Documents//TestNg//writeData.xlsx");
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sheet = wb.getSheet("Sheet1");
		System.out.println(sheet.getFirstRowNum());
		System.out.println(sheet.getLastRowNum());
		int rowCount = sheet.getLastRowNum()-sheet.getFirstRowNum();
		System.out.println(rowCount);
			}
}
